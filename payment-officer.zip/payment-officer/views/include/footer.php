
    <footer class="pt20 pb20">
        <div class="footer-copyright">
            <div class="container center">
                © Copyright <?php echo date('Y') ?>. All Rights Reserved
            </div>
        </div>
    </footer>